/**
 * This is the main class for the Fotoshop application
 * 
 * @author Joseph Williams
 * @version 09.01.2022
 */
public class Main {
   public static void main(String[] args) {

       Editor editor = new Editor(null, null, null, null);
       editor.set();
       editor.edit();
    }
}
